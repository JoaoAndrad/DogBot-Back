const express = require("express");
const basicAuth = require("../middleware/adminAuth");
const userService = require("../domains/users/service/userService");

const router = express.Router();

router.use(basicAuth);

// helper: sanitize BigInt values from Prisma results
function sanitizeBigInt(obj) {
  try {
    return JSON.parse(
      JSON.stringify(obj, (k, v) => (typeof v === "bigint" ? v.toString() : v)),
    );
  } catch (e) {
    return obj;
  }
}

// GET /admin/api/users
router.get("/", async (req, res) => {
  try {
    const page = parseInt(req.query.page || "1", 10);
    const per_page = parseInt(req.query.per_page || "20", 10);
    const q = req.query.q || undefined;
    const data = await userService.listUsers({ page, per_page, q });
    res.json(data);
  } catch (e) {
    console.log("users list error", e && e.message ? e.message : e);
    res.status(500).json({ error: "Failed to list users" });
  }
});

// POST /admin/api/users
router.post("/", express.json(), async (req, res) => {
  try {
    const payload = req.body || {};
    if (!payload.sender_number)
      return res.status(400).json({ error: "sender_number is required" });
    const created = await userService.createUser(payload);
    res.status(201).json(created);
  } catch (e) {
    console.log("user create error", e && e.message ? e.message : e);
    res.status(500).json({ error: "Failed to create user" });
  }
});

// GET /admin/api/users/:id
router.get("/:id", async (req, res) => {
  try {
    const user = await userService.getUser(req.params.id);
    if (!user) return res.status(404).json({ error: "User not found" });

    // sanitize BigInt values (Prisma returns BigInt for some numeric fields)
    function sanitizeBigInt(obj) {
      try {
        return JSON.parse(
          JSON.stringify(obj, (k, v) =>
            typeof v === "bigint" ? v.toString() : v,
          ),
        );
      } catch (e) {
        // fallback: return original object if serialization fails
        return obj;
      }
    }

    res.json(sanitizeBigInt(user));
  } catch (e) {
    console.error(
      "user detail error",
      e && (e.stack || e.message) ? e.stack || e.message : e,
    );
    // Return error details in admin API to aid debugging (admin auth required)
    res.status(500).json({
      error: "Failed to get user",
      message: e && e.message ? e.message : String(e),
    });
  }
});

// DEBUG: GET raw user record without joins (helps diagnose include-related failures)
router.get("/:id/raw", async (req, res) => {
  try {
    const id = req.params.id;
    const repo = require("../domains/users/repo/userRepo");
    const prisma = require("../../db").getPrisma();
    if (!prisma || !prisma.user)
      return res.status(500).json({ error: "Prisma client not available" });
    // Attempt a minimal select to avoid join issues
    const user = await prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        sender_number: true,
        display_name: true,
        metadata: true,
        identifiers: true,
        created_at: true,
      },
    });
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json({ raw: user });
  } catch (e) {
    console.error(
      "user raw detail error",
      e && (e.stack || e.message) ? e.stack || e.message : e,
    );
    res.status(500).json({
      error: "Failed to get raw user",
      message: e && e.message ? e.message : String(e),
    });
  }
});

// PATCH /admin/api/users/:id
router.patch("/:id", express.json(), async (req, res) => {
  try {
    const id = req.params.id;
    console.log("[admin] PATCH /admin/api/users/:id body:", req.body);
    // allow updating basic user fields plus sender_number and nested dogfort/fitness
    const allowed = [
      "display_name",
      "push_name",
      "metadata",
      "last_known_lid",
      "sender_number",
      "dogfort",
      "confessions",
      "fitness",
      "isAdmin",
    ];
    const payload = {};
    for (const k of allowed) if (k in req.body) payload[k] = req.body[k];
    if (Object.keys(payload).length === 0)
      return res.status(400).json({ error: "No updatable fields provided" });
    const updated = await userService.updateUser(id, payload);
    res.json(sanitizeBigInt(updated));
  } catch (e) {
    console.error(
      "user update error",
      e && (e.stack || e.message) ? e.stack || e.message : e,
    );
    // return error details for admin UI debugging
    res.status(500).json({
      error: "Failed to update user",
      message: e && e.message ? e.message : String(e),
    });
  }
});

// DELETE /admin/api/users/:id
router.delete("/:id", async (req, res) => {
  try {
    const id = req.params.id;
    await userService.deleteUser(id);
    res.json({ success: true });
  } catch (e) {
    console.log("user delete error", e && e.message ? e.message : e);
    res.status(500).json({ error: "Failed to delete user" });
  }
});

// POST /admin/api/users/:id/grant-admin
router.post("/:id/grant-admin", express.json(), async (req, res) => {
  try {
    const id = req.params.id;
    const updated = await userService.updateUser(id, { isAdmin: true });
    res.json(sanitizeBigInt(updated));
  } catch (e) {
    console.error("grant admin error", e && e.message ? e.message : e);
    res.status(500).json({ error: "Failed to grant admin status" });
  }
});

// DELETE /admin/api/users/:id/revoke-admin
router.delete("/:id/revoke-admin", async (req, res) => {
  try {
    const id = req.params.id;
    const updated = await userService.updateUser(id, { isAdmin: false });
    res.json(sanitizeBigInt(updated));
  } catch (e) {
    console.error("revoke admin error", e && e.message ? e.message : e);
    res.status(500).json({ error: "Failed to revoke admin status" });
  }
});

// POST /admin/api/users/bulk
router.post("/bulk", express.json(), async (req, res) => {
  try {
    const { ids, action } = req.body || {};
    if (!Array.isArray(ids) || !ids.length)
      return res.status(400).json({ error: "No ids provided" });
    const result = await userService.bulkUsers({ ids, action });
    res.json(result);
  } catch (e) {
    console.log("bulk users error", e && e.message ? e.message : e);
    res.status(500).json({ error: "Failed to perform bulk action" });
  }
});

module.exports = router;
